<?php
session_start();
require '../db_connect.php';

// Redirect to dashboard if already logged in
if (isset($_SESSION['staff_id'])) {
    header("Location: dashboard.php");
    exit();
}

$error_message = ""; 

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim(mysqli_real_escape_string($conn, $_POST['username']));
    $password = trim($_POST['password']);

    $stmt = $conn->prepare("SELECT id, first_name, last_name, password FROM staff WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows === 1) {
        $user = $result->fetch_assoc();
        
        if (password_verify($password, $user['password'])) {
            $_SESSION['staff_id'] = $user['id'];
            $_SESSION['staff_name'] = $user['first_name'] . ' ' . $user['last_name'];

            // Redirect to dashboard after successful login
            header("Location: dashboard.php");
            exit();
        } else {
            $error_message = "Incorrect password. Please try again.";
        }
    } else {
        $error_message = "Username not found. Please check your credentials.";
    }

    $stmt->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login</title>
    <link rel="stylesheet" href="styles.css">
    <style>
    @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap');
    body {
        background: url('img/marvsha.png') no-repeat center center fixed;
        background-size: cover;
        display: flex;
        font-family: Arial, sans-serif;
        background-color: #f4f4f4;
        display: flex;
        justify-content: center;
        align-items: center;
        height: 100vh;
        margin: 0;
    }
    .login-container {
        background: rgba(255, 255, 255, 0.48); /* Transparent White */
        backdrop-filter: blur(10px); /* Blur Effect */
        -webkit-backdrop-filter: blur(10px); /* For Safari */
        padding: 25px;
        border-radius: 15px;
        border: 5px solid rgba(254, 1, 1, 0.64); /* Soft Border */
        box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.2); 
        width: 350px;
        text-align: center;
    }
    h2 {
        font-family: 'Poppins', sans-serif; /* Poppins for Admin heading */
        color: #fff; /* White text for better visibility */
        font-weight: 600;
    }
    .error-message {
        color: red;
        font-size: 14px;
        margin-bottom: 10px;
    }
    .form-group {
        display: flex;
        flex-direction: column;
        align-items: flex-start; /* Aligning labels to the left */
        width: 100%;
        margin-bottom: 15px; /* Space between input fields */
    }
    label {
        font-family: 'Poppins', sans-serif; /* Poppins for labels */
        font-weight: 600;
        margin-bottom: 5px;
        text-align: left;
        color: #fff; /* White labels */
    }

    input {
        width: 100%;
        padding: 10px;
        border: 1px solid rgba(255, 255, 255, 0.3);
        border-radius: 8px;
        box-sizing: border-box;
        margin-bottom: 10px; /* Spacing between inputs */
        background: rgba(255, 255, 255, 0.2);
        backdrop-filter: blur(5px);
        -webkit-backdrop-filter: blur(5px);
        color: #fff;
        outline: none;
        transition: all 0.3s ease-in-out;
    }
    
    button {
        font-family: 'Poppins', sans-serif; /* Poppins for Login button */
        background: #ffcc00;
        color: #333;
        padding: 10px;
        border: none;
        border-radius: 5px;
        cursor: pointer;
        width: 100%;
        margin-top: 10px;
        font-weight: bold;
    }
    button:hover {
        background: #e6b800;
    }
</style>

</head>
<body>
    <div class="login-container">
        <h2>Admin Login</h2>
        
        <?php if (!empty($error_message)): ?>
            <p class="error-message"><?php echo htmlspecialchars($error_message); ?></p>
        <?php endif; ?>

        <form method="POST">
            <label>Username:</label>
            <input type="text" name="username" required>

            <label>Password:</label>
            <input type="password" name="password" required>

            <button type="submit">Login</button>
        </form>
    </div>
</body>
</html>